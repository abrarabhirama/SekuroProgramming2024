// Nama : Abrar Abhirama Widyadhana
// Fakultas : STEI-K

// Keluarannya adalah
// 10
// 0x111111
// 0x444444
// 0x333333
// 10
// 0x222222
// 10
// 200

// cout<<a<<endl;  nampilin nilai a = 10

// cout<<&a<<endl; asumsi a 0x111111

// cout<<pb<<endl; pb yang menunujuk b dengan asumsi 0x444444

// cout<<ppa<<endl; ppa yang menujuk pa dengan asumms 0x333333

// cout<<*pa<<endl; menampilkan pointer oleh pa yaitu a 10

// cout<<*ppb<<endl; menampilkan pointer oleh ppb yaitu b 20

// cout<<**ppa<<endl; menampilkan pointer ppa ya itu a 10

// cout<<*pb * **ppb<<endl; hasil perkalian b dengan a = 200